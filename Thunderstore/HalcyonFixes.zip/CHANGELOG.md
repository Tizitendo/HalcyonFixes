## 1.1.0
- Fixed Halcyonites attacks overlapping with his spawn animation

## 1.0.0
- First release