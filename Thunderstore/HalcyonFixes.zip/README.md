# HalcyonFixes

Fixes some bugs with halcyonites AI such as

- halcyon sometimes changing direction during its helicopter
- halcyons attack getting interrupted by other attacks
- halcyons attacks overlapping with his spawn animation
- halcyon flying to your past position instead of current
- halcyons flying animation sometimes not ending correctly
- halcyon floating after interrupting its helicopter attack within the first half second
- halcyon flying around aimlessly if player leaves certain radius during its helicopter

## Contact
For questions or bug reports, you can find me in the [RoR2 Modding Server](https://discord.gg/YxEdVK7xWM) @Onyx